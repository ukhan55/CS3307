# 3307 Traffic Light Assignment
# breathe.py
#   Animation for strip of NeoPixels to breathe random colours.
#
# Author: Patrick Mihalcea (251023246)
#
# Group 14. Last Edited: Nov 25 2021

# The following repository was referenced; some methods were helpful in the development of our patterns:
# https://github.com/jgarff/rpi_ws281x

import time
import random
from rpi_ws281x import *
import argparse

# LED strip configuration:
LED_COUNT = 150      # Number of LED pixels.
LED_PIN = 18      # GPIO pin connected to the pixels (18 uses PWM!).
LED_FREQ_HZ = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
# True to invert the signal (when using NPN transistor level shift)
LED_INVERT = False
LED_CHANNEL = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53


def colorWipe(strip, color, wait_ms=50):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)  # Color given as rgb.


def breathe(strip, wait_ms=60, iterations=1):
    randColor = Color(random.randint(0, 255), random.randint(
        0, 255), random.randint(0, 255))

    colorWipe(strip, randColor)
    # Changes how many times to breathe on each color.
    for a in range(1*iterations):
        # Go up in brightness.
        for x in range(0, 25):
            # Read runFlag file to determine if process should continue.
            # When another button is clicked on the controller, this process will end.
            f = open(
                '/home/pi/Traffic Light 2021/build-groupProject-Desktop-Debug/runFlag.txt', 'r')
            flag = f.read()
            f.close()
            if flag != '1':
                return
            strip.setBrightness(x*10)
            time.sleep(wait_ms/1000.0)
            strip.show()
        # Go down in brightness.
        for x in range(25, 0, -1):
            # Check again if process should continue.
            f = open(
                '/home/pi/Traffic Light 2021/build-groupProject-Desktop-Debug/runFlag.txt', 'r')
            flag = f.read()
            f.close()
            if flag != '1':
                return
            strip.setBrightness(x*10)
            time.sleep(wait_ms/1000.0)
            strip.show()
    # Run again until loop is exited by another button press.
    breathe(strip)


# Main program logic follows:
if __name__ == '__main__':
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--clear', action='store_true',
                        help='clear the display on exit')
    # Useful for testing python code independently from Qt controller.
    args = parser.parse_args()

    # Create NeoPixel object with appropriate configuration.
    strip = Adafruit_NeoPixel(
        LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    # Intialize the library (must be called once before other functions).
    strip.begin()

    try:
        breathe(strip)  # Breathe
        print('Done Breathing')
        exit()

    except KeyboardInterrupt:
        if args.clear:
            colorWipe(strip, Color(0, 0, 0), 10)
