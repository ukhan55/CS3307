var searchData=
[
  ['blueb_53',['blueB',['../classMainWindow.html#aef976828e07280613d8d95bac68140db',1,'MainWindow']]],
  ['breathebutton_54',['breatheButton',['../classMainWindow.html#a8d255a18befff8197c46df9486ecdabf',1,'MainWindow']]]
];
