var searchData=
[
  ['green_18',['green',['../classMainWindow.html#ab37a91263278e32d94d82ad2fc998b1d',1,'MainWindow']]],
  ['greenb_19',['greenB',['../classMainWindow.html#a3191cb62273047ce9b53d4aee57477b0',1,'MainWindow']]]
];
