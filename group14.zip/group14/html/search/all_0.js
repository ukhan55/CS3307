var searchData=
[
  ['adjustbrightness_0',['adjustBrightness',['../classMainWindow.html#a464a2bd06fe0930509046c6e6eb5b2fd',1,'MainWindow']]]
];
