var searchData=
[
  ['load_20',['load',['../classMainWindow.html#a6e04700a16c46ab29b095c4825e7fed4',1,'MainWindow']]],
  ['loadb_21',['loadB',['../classMainWindow.html#a006c101d674d660633e12f2ba2bc1961',1,'MainWindow']]]
];
