var searchData=
[
  ['s1_93',['s1',['../classMainWindow.html#ae055bd7f8a53c8a9682abba47d04d46b',1,'MainWindow']]],
  ['s2_94',['s2',['../classMainWindow.html#aace8ee916b0f685bb621885793ea87e5',1,'MainWindow']]],
  ['s3_95',['s3',['../classMainWindow.html#a00f372cac53fcea4dc8391a1cf6ea15c',1,'MainWindow']]],
  ['save_96',['save',['../classMainWindow.html#acdbfb29d83177d7c8acd82f687711561',1,'MainWindow']]],
  ['saveload_97',['saveload',['../classMainWindow.html#aa114856f9467fe0130c51b088265ffcb',1,'MainWindow']]],
  ['slflag_98',['slFlag',['../classMainWindow.html#a3d878aaa117b29afa0f64dbeb691a6bb',1,'MainWindow']]],
  ['states_99',['states',['../classMainWindow.html#a043c62b72f0f33317d43250ea9c48500',1,'MainWindow']]]
];
