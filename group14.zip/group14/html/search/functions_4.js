var searchData=
[
  ['loadb_58',['loadB',['../classMainWindow.html#a006c101d674d660633e12f2ba2bc1961',1,'MainWindow']]]
];
