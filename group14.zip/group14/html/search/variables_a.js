var searchData=
[
  ['widget_101',['widget',['../classMainWindow.html#a226229415e86ba6f862cd7425f78eaa3',1,'MainWindow']]]
];
