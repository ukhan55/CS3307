var searchData=
[
  ['blue_1',['blue',['../classMainWindow.html#a5e18de38a63dd4b4807bfdbe5d660a15',1,'MainWindow']]],
  ['blueb_2',['blueB',['../classMainWindow.html#aef976828e07280613d8d95bac68140db',1,'MainWindow']]],
  ['breatheb_3',['breatheB',['../classMainWindow.html#a6f12ceef42367de311c8b40682d40843',1,'MainWindow']]],
  ['breathebutton_4',['breatheButton',['../classMainWindow.html#a8d255a18befff8197c46df9486ecdabf',1,'MainWindow']]],
  ['bright_5',['bright',['../classMainWindow.html#a752f03511b3d01c6201c088df6253ec9',1,'MainWindow']]],
  ['brightlabel_6',['brightLabel',['../classMainWindow.html#a6779dd5deee86a2b4c81efd707aaf9ed',1,'MainWindow']]],
  ['brightness_7',['brightness',['../classMainWindow.html#aeb3059ed238b53f5080c5ceb9d0b1a02',1,'MainWindow']]]
];
