var searchData=
[
  ['offb_60',['offB',['../classMainWindow.html#a9bb78d93516316603731d9ac5f55b8d5',1,'MainWindow']]]
];
