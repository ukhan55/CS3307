var searchData=
[
  ['colourbuttons_78',['colourButtons',['../classMainWindow.html#a1de1c98841147e712ddce4d092850bf7',1,'MainWindow']]],
  ['colourlabel_79',['colourLabel',['../classMainWindow.html#a2479c158d39287e7731bdb346b828ead',1,'MainWindow']]],
  ['controller_80',['controller',['../classMainWindow.html#a9a657ce28475a20480a0369f118532e0',1,'MainWindow']]],
  ['controllerlabel_81',['controllerLabel',['../classMainWindow.html#aef00494bcc136e3f64f96c4611384322',1,'MainWindow']]],
  ['current_82',['current',['../classMainWindow.html#a6ec7ffef8483501604099a83431c51c4',1,'MainWindow']]],
  ['currentsel_83',['currentSel',['../classMainWindow.html#aaccc8e834c1dca05eedb110cb50caea0',1,'MainWindow']]]
];
