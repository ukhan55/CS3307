var searchData=
[
  ['s1_35',['s1',['../classMainWindow.html#ae055bd7f8a53c8a9682abba47d04d46b',1,'MainWindow']]],
  ['s1b_36',['s1B',['../classMainWindow.html#addc67429ab0ffa1a97c88ad850497e1e',1,'MainWindow']]],
  ['s2_37',['s2',['../classMainWindow.html#aace8ee916b0f685bb621885793ea87e5',1,'MainWindow']]],
  ['s2b_38',['s2B',['../classMainWindow.html#a9cc179e3dbd2a320f165a926543b4bd6',1,'MainWindow']]],
  ['s3_39',['s3',['../classMainWindow.html#a00f372cac53fcea4dc8391a1cf6ea15c',1,'MainWindow']]],
  ['s3b_40',['s3B',['../classMainWindow.html#a5e917096176db47dd7809988727aab73',1,'MainWindow']]],
  ['save_41',['save',['../classMainWindow.html#acdbfb29d83177d7c8acd82f687711561',1,'MainWindow']]],
  ['saveb_42',['saveB',['../classMainWindow.html#a548300e94a393d94b3e1bbac4b6d1330',1,'MainWindow']]],
  ['saveload_43',['saveload',['../classMainWindow.html#aa114856f9467fe0130c51b088265ffcb',1,'MainWindow']]],
  ['slflag_44',['slFlag',['../classMainWindow.html#a3d878aaa117b29afa0f64dbeb691a6bb',1,'MainWindow']]],
  ['states_45',['states',['../classMainWindow.html#a043c62b72f0f33317d43250ea9c48500',1,'MainWindow']]]
];
