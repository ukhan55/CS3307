var searchData=
[
  ['s1b_66',['s1B',['../classMainWindow.html#addc67429ab0ffa1a97c88ad850497e1e',1,'MainWindow']]],
  ['s2b_67',['s2B',['../classMainWindow.html#a9cc179e3dbd2a320f165a926543b4bd6',1,'MainWindow']]],
  ['s3b_68',['s3B',['../classMainWindow.html#a5e917096176db47dd7809988727aab73',1,'MainWindow']]],
  ['saveb_69',['saveB',['../classMainWindow.html#a548300e94a393d94b3e1bbac4b6d1330',1,'MainWindow']]]
];
