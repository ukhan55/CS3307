var searchData=
[
  ['usecurrentsel_48',['useCurrentSel',['../classMainWindow.html#ab3b3b3219afcaf8da028c7b66bfd8054',1,'MainWindow']]]
];
