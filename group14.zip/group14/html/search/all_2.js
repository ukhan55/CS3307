var searchData=
[
  ['changebrightness_8',['changeBrightness',['../classMainWindow.html#a4273849c879535967ee47f44ac0b5627',1,'MainWindow']]],
  ['changerunflag_9',['changeRunFlag',['../classMainWindow.html#a517170232293094546f067ccaeb98b06',1,'MainWindow']]],
  ['colourbuttons_10',['colourButtons',['../classMainWindow.html#a1de1c98841147e712ddce4d092850bf7',1,'MainWindow']]],
  ['colourlabel_11',['colourLabel',['../classMainWindow.html#a2479c158d39287e7731bdb346b828ead',1,'MainWindow']]],
  ['controller_12',['controller',['../classMainWindow.html#a9a657ce28475a20480a0369f118532e0',1,'MainWindow']]],
  ['controllerlabel_13',['controllerLabel',['../classMainWindow.html#aef00494bcc136e3f64f96c4611384322',1,'MainWindow']]],
  ['cs3307_20group_2014_27s_20project_14',['CS3307 Group 14&apos;s Project',['../md_README.html',1,'']]],
  ['current_15',['current',['../classMainWindow.html#a6ec7ffef8483501604099a83431c51c4',1,'MainWindow']]],
  ['currentsel_16',['currentSel',['../classMainWindow.html#aaccc8e834c1dca05eedb110cb50caea0',1,'MainWindow']]]
];
