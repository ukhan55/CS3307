var searchData=
[
  ['rainbowbutton_63',['rainbowButton',['../classMainWindow.html#affc5f8592d4cc6ee22ceee88543e5554',1,'MainWindow']]],
  ['redb_64',['redB',['../classMainWindow.html#ae95a39d32340b80093b99565cba13192',1,'MainWindow']]],
  ['refreshcurrentsel_65',['refreshCurrentSel',['../classMainWindow.html#acd69694da4cb5e3496e9170ff0fa9bd3',1,'MainWindow']]]
];
