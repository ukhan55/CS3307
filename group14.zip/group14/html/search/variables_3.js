var searchData=
[
  ['green_85',['green',['../classMainWindow.html#ab37a91263278e32d94d82ad2fc998b1d',1,'MainWindow']]]
];
