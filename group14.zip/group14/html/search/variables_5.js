var searchData=
[
  ['off_87',['off',['../classMainWindow.html#a885c50397b8a44b3e6e09e705abb4c9e',1,'MainWindow']]]
];
