var searchData=
[
  ['greenb_57',['greenB',['../classMainWindow.html#a3191cb62273047ce9b53d4aee57477b0',1,'MainWindow']]]
];
