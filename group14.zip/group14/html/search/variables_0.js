var searchData=
[
  ['blue_73',['blue',['../classMainWindow.html#a5e18de38a63dd4b4807bfdbe5d660a15',1,'MainWindow']]],
  ['breatheb_74',['breatheB',['../classMainWindow.html#a6f12ceef42367de311c8b40682d40843',1,'MainWindow']]],
  ['bright_75',['bright',['../classMainWindow.html#a752f03511b3d01c6201c088df6253ec9',1,'MainWindow']]],
  ['brightlabel_76',['brightLabel',['../classMainWindow.html#a6779dd5deee86a2b4c81efd707aaf9ed',1,'MainWindow']]],
  ['brightness_77',['brightness',['../classMainWindow.html#aeb3059ed238b53f5080c5ceb9d0b1a02',1,'MainWindow']]]
];
