var searchData=
[
  ['changebrightness_55',['changeBrightness',['../classMainWindow.html#a4273849c879535967ee47f44ac0b5627',1,'MainWindow']]],
  ['changerunflag_56',['changeRunFlag',['../classMainWindow.html#a517170232293094546f067ccaeb98b06',1,'MainWindow']]]
];
