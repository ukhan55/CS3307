var searchData=
[
  ['load_86',['load',['../classMainWindow.html#a6e04700a16c46ab29b095c4825e7fed4',1,'MainWindow']]]
];
