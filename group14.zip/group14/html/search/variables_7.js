var searchData=
[
  ['rainbowb_91',['rainbowB',['../classMainWindow.html#a2d1d6497ba3f52e44747aec6137a1e22',1,'MainWindow']]],
  ['red_92',['red',['../classMainWindow.html#a9f5ed93fe20ae199acae43fb724ac147',1,'MainWindow']]]
];
