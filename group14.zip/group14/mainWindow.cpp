
#include "mainWindow.h"
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QSlider>
#include <QStateMachine>
#include <QEventTransition>
#include <QPropertyAnimation>
#include <QPalette>
#include <string>
#include <fstream>
#include <iostream>
#include <QProcess>
#include <QCoreApplication>
#include <QThread>
#include <QMediaPlayer>
#include <QSound>

/**
 * @author Joseph Siy, Nada Elkelani, Patrick Mihalcea, Brian Cheng, Usman Khan
 * Constructor for MainWindow class that instantiates the controller and also performs all interactive UI functions.
 */
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    slFlag = 0; //0 indicates save/write
    currentSel = {"", ""};
    currentSel[0] = "100"; // Set default to 100.
    std::string s = "";
    for (int i = 0; i < 2; i++)
    {
        s += currentSel[i];
        if (i != 1)
        {
            s += ", ";
        }
    }
    current = new QTextEdit(this);
    current->setText(QString::fromStdString(s));
    //lable the qt box so that the user knows its a light controller
    controllerLabel = new QLabel("Light Controller 1.4", this);
    controllerLabel->setAlignment(Qt::AlignCenter);

    //create the slider
    brightness = new QSlider(Qt::Horizontal, this);
    brightness->setRange(1, 255);
    changeBrightness(100);
    brightLabel = new QLabel("Brightness", this);
    bright = new QHBoxLayout;
    bright->addWidget(brightLabel);
    bright->addWidget(brightness);

    //creating the buttons:
    //the following will be on the same widet board
    breatheB = new QPushButton("Breathe", this);
    trafficB = new QPushButton("Traffic Route", this);
    policeB = new QPushButton("Police Chase", this);
    partyB = new QPushButton("Party", this);
    rainbowB = new QPushButton("Rainbow", this);

    patternButtons = new QVBoxLayout;
    patternButtons->addWidget(breatheB);
    patternButtons->addWidget(trafficB);
    patternButtons->addWidget(policeB);
    patternButtons->addWidget(partyB);
    patternButtons->addWidget(rainbowB);

    states = new QHBoxLayout;
    s1 = new QPushButton("State 1", this);
    s2 = new QPushButton("State 2", this);
    s3 = new QPushButton("State 3", this);
    states->addWidget(s1);
    states->addWidget(s2);
    states->addWidget(s3);

    saveload = new QHBoxLayout;
    save = new QPushButton("Save", this);
    load = new QPushButton("Load", this);
    saveload->addWidget(save);
    saveload->addWidget(load);

    red = new QPushButton("Red", this);
    blue = new QPushButton("Blue", this);
    green = new QPushButton("Green", this);
    off = new QPushButton("Off", this);

    //then we create a lable for the colours
    colourLabel = new QLabel("Solid Colours: ", this);

    colourButtons = new QHBoxLayout;
    colourButtons->addWidget(colourLabel);
    colourButtons->addWidget(red);
    colourButtons->addWidget(blue);
    colourButtons->addWidget(green);
    colourButtons->addWidget(off);

    //creating the main widet box to add the above on the one widget as the controller
    controller = new QVBoxLayout;
    controller->addWidget(controllerLabel);
    controller->addWidget(current);
    controller->addLayout(saveload);
    controller->addLayout(states);
    controller->addLayout(bright);
    controller->addLayout(patternButtons);
    controller->addLayout(colourButtons);

    //this is going to make the controller the main widget
    QWidget *theWholeController = new QWidget;
    //set the controller to be the main
    theWholeController->setLayout(controller);
    //the central widget is going to be the widget in which contains the controller layout
    setCentralWidget(theWholeController);

    //again, this could change depending on how we want to do the solid colour
    connect(breatheB, &QPushButton::released, this, &MainWindow::breatheButton);
    connect(trafficB, &QPushButton::released, this, &MainWindow::trafficButton);
    connect(policeB, &QPushButton::released, this, &MainWindow::policeButton);
    connect(partyB, &QPushButton::released, this, &MainWindow::partyButton);
    connect(rainbowB, &QPushButton::released, this, &MainWindow::rainbowButton);

    connect(red, &QPushButton::released, this, &MainWindow::redB);
    connect(blue, &QPushButton::released, this, &MainWindow::blueB);
    connect(green, &QPushButton::released, this, &MainWindow::greenB);
    connect(off, &QPushButton::released, this, &MainWindow::offB);

    connect(s1, &QPushButton::released, this, &MainWindow::s1B);
    connect(s2, &QPushButton::released, this, &MainWindow::s2B);
    connect(s3, &QPushButton::released, this, &MainWindow::s3B);

    connect(save, &QPushButton::released, this, &MainWindow::saveB);
    connect(load, &QPushButton::released, this, &MainWindow::loadB);

    connect(brightness, &QSlider::valueChanged, this, &MainWindow::adjustBrightness);
}

/**
 * @author Joseph Siy
 * 
 * Helper function to build current selection string based on the array
 */
void MainWindow::refreshCurrentSel()
{
    std::string s = "";
    for (int i = 0; i < 2; i++)
    {
        s += currentSel[i];
        if (i != 1)
        {
            s += ", ";
        }
    }
    current->setText(QString::fromStdString(s));
}

/**
 * @author Joseph Siy
 * 
 * Helper function to simulate the pressing of buttons based on the state of the current selection.
 * Called upon loading a state
 */
void MainWindow::useCurrentSel()
{
    //colour
    if (currentSel[1] == "Red")
    {
        redB();
    }
    else if (currentSel[1] == "Blue")
    {
        blueB();
    }
    else if (currentSel[1] == "Green")
    {
        greenB();
    }
    else if (currentSel[1] == "Off")
    {
        offB();
    }
    //mode
    if (currentSel[1] == "Breathe")
    {
        breatheButton();
    }
    else if (currentSel[1] == "Traffic Route")
    {
        trafficButton();
    }
    else if (currentSel[1] == "Police Chase")
    {
        policeButton();
    }
    else if (currentSel[1] == "Party")
    {
        partyButton();
    }
    else if (currentSel[1] == "Rainbow")
    {
        rainbowButton();
    }
}

/**
 * @author Joseph Siy
 * Flips the save/load flag to save, meaning state buttons will write to text file.
 */
void MainWindow::saveB()
{
    slFlag = 0;
}

/**
 * @author Joseph Siy
 * Flips the save/load flag to load, meaning the state buttons will read from text file.
 */
void MainWindow::loadB()
{
    slFlag = 1;
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the "mode" to breathing lights. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::breatheButton()
{
    // Kill previous process if there is one.
    changeRunFlag(0);
    QThread::msleep(80); // Delay a short time for previous process to read updated flag.

    QString temp = breatheB->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    // Return runFlag to 1 to signal a process is about to run.
    changeRunFlag(1);

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/breathe.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/breathe.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the "mode" to traffic light. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::trafficButton()
{
    // Kill previous process if there is one.
    changeRunFlag(0);
    QThread::msleep(80); // Delay a short time for previous process to read updated flag.

    QString temp = trafficB->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    // Return runFlag to 1 to signal a process is about to run.
    changeRunFlag(1);

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/trafficLight.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/trafficLight.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the "mode" to police lights. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::policeButton()
{
    // Kill previous process if there is one.
    changeRunFlag(0);
    QThread::msleep(80); // Delay a short time for previous process to read updated flag.

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/policeSiren.wav"));
    player->setVolume(10);
    player->play();

    QString temp = policeB->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    // Return runFlag to 1 to signal a process is about to run.
    changeRunFlag(1);

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/police.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the "mode" to party lights. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::partyButton()
{
    // Kill previous process if there is one.
    changeRunFlag(0);
    QThread::msleep(80); // Delay a short time for previous process to read updated flag.

    QString temp = partyB->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    // Return runFlag to 1 to signal a process is about to run.
    changeRunFlag(1);

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/party.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/party.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the "mode" to rainbow lights. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::rainbowButton()
{
    // Kill previous process if there is one.
    changeRunFlag(0);
    QThread::msleep(80); // Delay a short time for previous process to read updated flag.

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/rainbow.wav"));
    player->setVolume(50);
    player->play();

    QString temp = rainbowB->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    // Return runFlag to 1 to signal a process is about to run.
    changeRunFlag(1);

    // Run process.
    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/rainbow.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the colour to red. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::redB()
{
    // Kill previous process if there is one.
    changeRunFlag(0);

    QString temp = red->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/red.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/red.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the colour to blue. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::blueB()
{
    // Kill previous process if there is one.
    changeRunFlag(0);

    QString temp = blue->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/blue.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/blue.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that changes the colour to green. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::greenB()
{
    // Kill previous process if there is one.
    changeRunFlag(0);

    QString temp = green->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/green.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/green.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * 
 * Event handler that turns the light off. Invokes the appropriate python script, playing audio and changing the light to reflect the new setting.
 */
void MainWindow::offB()
{
    // Kill previous process if there is one.
    changeRunFlag(0);

    QString temp = off->text();
    std::string buttonText = temp.toStdString();
    currentSel[1] = buttonText;
    refreshCurrentSel();

    QMediaPlayer *player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("/home/pi/Traffic Light 2021/Qt5 1.4/off.wav"));
    player->setVolume(50);
    player->play();

    QString path = QCoreApplication::applicationDirPath();
    QString program("python3");
    QStringList params = QStringList() << "/home/pi/Traffic Light 2021/Qt5 1.4/off.py";
    QProcess *process = new QProcess();
    process->startDetached(program, params, path);
    process->waitForFinished();
    process->close();
}

/**
 * @author Joseph Siy
 * Event handler that will dynamically read or write from/to state1.txt depending on the save/load flag
 * @see s2B()
 * @see s3B()
 */
void MainWindow::s1B()
{
    if (slFlag == 0)
    {
        std::ofstream fout("state1.txt");
        for (int i = 0; i < 2; i++)
        {
            fout << currentSel[i];
            if (i != 1)
            {
                fout << ",";
            }
        }
        fout.close();
    }
    else if (slFlag == 1)
    {
        std::string line;
        std::ifstream fin("state1.txt");
        getline(fin, line);
        for (int i = 0; i < 2; i++)
        {
            int split = line.find(",");
            currentSel[i] = line.substr(0, split);
            if (i == 0)
            {
                changeBrightness(stoi(currentSel[0]));
            }
            line = line.substr(split + 1);
        }
        refreshCurrentSel();
        useCurrentSel();
    }
}

/**
 * @author Joseph Siy
 * Event handler that will dynamically read or write from/to state2.txt depending on the save/load flag
 * @see s1B()
 * @see s3B()
 */
void MainWindow::s2B()
{
    if (slFlag == 0)
    {
        std::ofstream fout("state2.txt");
        for (int i = 0; i < 2; i++)
        {
            fout << currentSel[i];
            if (i != 1)
            {
                fout << ",";
            }
        }
        fout.close();
    }
    else if (slFlag == 1)
    {
        std::string line;
        std::ifstream fin("state2.txt");
        getline(fin, line);
        for (int i = 0; i < 2; i++)
        {
            int split = line.find(",");
            currentSel[i] = line.substr(0, split);
            if (i == 0)
            {
                changeBrightness(stoi(currentSel[0]));
            }
            line = line.substr(split + 1);
        }
        refreshCurrentSel();
        useCurrentSel();
    }
}

/**
 * @author Joseph Siy
 * Event handler that will dynamically read or write from/to state3.txt depending on the save/load flag
 * @see s2B()
 * @see s1B()
 */
void MainWindow::s3B()
{
    if (slFlag == 0)
    {
        std::ofstream fout("state3.txt");
        for (int i = 0; i < 2; i++)
        {
            fout << currentSel[i];
            if (i != 1)
            {
                fout << ",";
            }
        }
        fout.close();
    }
    else if (slFlag == 1)
    {
        std::string line;
        std::ifstream fin("state3.txt");
        getline(fin, line);
        for (int i = 0; i < 2; i++)
        {
            int split = line.find(",");
            currentSel[i] = line.substr(0, split);
            if (i == 0)
            {
                changeBrightness(stoi(currentSel[0]));
            }
            line = line.substr(split + 1);
        }
        refreshCurrentSel();
        useCurrentSel();
    }
}

/**
 * @author Joseph Siy
 * Helper function that adjusts brightness in selection to reflect the slider's value
 */
void MainWindow::adjustBrightness()
{
    int brightVal = brightness->value();
    std::string s = std::to_string(brightVal);

    changeBrightness(brightVal);

    currentSel[0] = s;
    refreshCurrentSel();
}

/**
 * @author Joseph Siy
 * @param brightnessInput the desired brightness value
 * Helper function that adjusts the brightness and ensure text file's value reflects actual value.
 */
void MainWindow::changeBrightness(int brightnessInput)
{
    brightness->setValue(brightnessInput);
    std::ofstream fout("brightness.txt");
    fout << brightnessInput;
    fout.close();
}

/**
 * @author Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
 * @param runFlag flag indicating whether a process is running; written to the text file
 * Function that updates a text file with a flag that represents whether a process is currently running.
 */
void MainWindow::changeRunFlag(int runFlag)
{
    std::ofstream fout("runFlag.txt"); // Open runFlag.txt file.
    fout << runFlag;                   // Write the flag to the file.
    fout.close();                      // Close the file.
}

/**
 * @author Nada Elkelani
 * Empty deconstructor.
 */
MainWindow::~MainWindow()
{
}
