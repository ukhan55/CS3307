# 3307 Traffic Light Assignment
# trafficLight.py
#   Animation for strip of NeoPixels to emulate 4-way traffic light.
#   States are created for every arrangement of lights on a traffic light,
#   States are then looped through in order to look like traffic light.
#
# Authors: Patrick Mihalcea, Nada Elkelani, Brian Cheng, Usman Khan
#
# Group 14. Last Edited: Nov 27 2021

# The following repository was referenced; some methods were helpful in the development of our patterns:
# https://github.com/jgarff/rpi_ws281x

import time
from rpi_ws281x import *
import argparse

# LED strip configuration:
LED_COUNT = 150      # Number of LED pixels.
LED_PIN = 18      # GPIO pin connected to the pixels (18 uses PWM!).
LED_FREQ_HZ = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
# True to invert the signal (when using NPN transistor level shift)
LED_INVERT = False
LED_CHANNEL = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53


def colorWipe(strip, color, wait_ms=50):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)  # Color given as rgb.

# Red N/S, Green E/W


def state1(strip, brightness, wait_ms=40):
    # Green Lights
    for a in range(139, 142):
        strip.setPixelColor(a, Color(0, brightness, 0))
    for b in range(110, 113):
        strip.setPixelColor(b, Color(0, brightness, 0))

    for c in range(119, 122):
        strip.setPixelColor(c, Color(0, brightness, 0))
    for d in range(90, 93):
        strip.setPixelColor(d, Color(0, brightness, 0))

    # Red Light
    for e in range(71, 74):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(46, 49):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    # Red Light
    for g in range(53, 56):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(78, 81):
        strip.setPixelColor(h, Color(brightness, 0, 0))
    strip.show()


# Green N/S, Green E/W
def state2(strip, brightness, wait_ms=40):
    # Green Lights
    for a in range(65, 68):
        strip.setPixelColor(a, Color(0, brightness, 0))
    for b in range(40, 43):
        strip.setPixelColor(b, Color(0, brightness, 0))

    for c in range(58, 61):
        strip.setPixelColor(c, Color(0, brightness, 0))
    for d in range(83, 86):
        strip.setPixelColor(d, Color(0, brightness, 0))

    # Red Light
    for e in range(105, 108):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(134, 137):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    # Red Light
    for g in range(125, 128):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(96, 99):
        strip.setPixelColor(h, Color(brightness, 0, 0))
    strip.show()

# All red


def state3(strip, brightness, wait_ms=40):

    for e in range(71, 74):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(46, 49):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    # Red Light
    for g in range(53, 56):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(78, 81):
        strip.setPixelColor(h, Color(brightness, 0, 0))

    for e in range(105, 108):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(134, 137):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    # Red Light
    for g in range(125, 128):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(96, 99):
        strip.setPixelColor(h, Color(brightness, 0, 0))
    strip.show()

# Yellow N/S, Red E/W


def state4(strip, brightness, wait_ms=40):
    # Yello Lights
    for e in range(68, 71):
        strip.setPixelColor(
            e, Color(round(brightness*0.7), round(brightness*0.3), 0))
    for f in range(43, 46):
        strip.setPixelColor(
            f, Color(round(brightness*0.7), round(brightness*0.3), 0))

    for g in range(55, 58):
        strip.setPixelColor(
            g, Color(round(brightness*0.7), round(brightness*0.3), 0))
    for h in range(80, 83):
        strip.setPixelColor(
            h, Color(round(brightness*0.7), round(brightness*0.3), 0))

        # Red Lights
    for e in range(105, 108):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(134, 137):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    for g in range(125, 128):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(96, 99):
        strip.setPixelColor(h, Color(brightness, 0, 0))
    strip.show()

# Red N/S, Yellow E/W


def state5(strip, brightness, wait_ms=40):
    # Red Lights
    for e in range(71, 74):
        strip.setPixelColor(e, Color(brightness, 0, 0))
    for f in range(46, 49):
        strip.setPixelColor(f, Color(brightness, 0, 0))

    for g in range(53, 56):
        strip.setPixelColor(g, Color(brightness, 0, 0))
    for h in range(78, 81):
        strip.setPixelColor(h, Color(brightness, 0, 0))

        # Yellow Lights
    for e in range(107, 110):
        strip.setPixelColor(
            e, Color(round(brightness*0.7), round(brightness*0.3), 0))
    for f in range(136, 139):
        strip.setPixelColor(
            f, Color(round(brightness*0.7), round(brightness*0.3), 0))

    for g in range(122, 125):
        strip.setPixelColor(
            g, Color(round(brightness*0.7), round(brightness*0.3), 0))
    for h in range(93, 96):
        strip.setPixelColor(
            h, Color(round(brightness*0.7), round(brightness*0.3), 0))
    strip.show()


def check():
    # Check again if process should continue.
    f = open(
        '/home/pi/Traffic Light 2021/build-groupProject-Desktop-Debug/runFlag.txt', 'r')
    flag = f.read()
    f.close()
    return flag


# Main program logic follows:
if __name__ == '__main__':
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--clear', action='store_true',
                        help='clear the display on exit')
    # Useful for testing python code independently from Qt controller.
    args = parser.parse_args()

    # Create NeoPixel object with appropriate configuration.
    strip = Adafruit_NeoPixel(
        LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    # Intialize the library (must be called once before other functions).
    strip.begin()

    # Get Brightness
    f = open(
        '/home/pi/Traffic Light 2021/build-groupProject-Desktop-Debug/brightness.txt', 'r')
    brightnessString = f.read()
    brightness = int(brightnessString)
    f.close()

    try:
        # Check if code should run.
        flag = check()
        while flag == '1':
            colorWipe(strip, Color(0, 0, 0))
            state3(strip, brightness)
            time.sleep(1)
            flag = check()
            if flag == '0':
                break  # Exit loop when another button is pressed.
            colorWipe(strip, Color(0, 0, 0))
            state1(strip, brightness)
            time.sleep(1)
            flag = check()
            if flag == '0':
                break
            colorWipe(strip, Color(0, 0, 0))
            state5(strip, brightness)
            time.sleep(1)
            flag = check()
            if flag == '0':
                break
            colorWipe(strip, Color(0, 0, 0))
            state3(strip, brightness)
            time.sleep(1)
            flag = check()
            if flag == '0':
                break
            colorWipe(strip, Color(0, 0, 0))
            state2(strip, brightness)
            time.sleep(1)
            flag = check()
            if flag == '0':
                break
            colorWipe(strip, Color(0, 0, 0))
            state4(strip, brightness)
            time.sleep(1)
            flag = check()

        print('Done Traffic')
        exit()

    except KeyboardInterrupt:
        if args.clear:
            colorWipe(strip, Color(0, 0, 0), 10)
