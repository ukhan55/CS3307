# 3307 Traffic Light Assignment
# red.py
#   Animation for strip of NeoPixels to turn them all red.
#
# Author: Patrick Mihalcea (251023246)
#
# Group 14. Last Edited: Nov 11 2021


import time
from rpi_ws281x import *
import argparse

# LED strip configuration:
LED_COUNT = 150      # Number of LED pixels.
LED_PIN = 18      # GPIO pin connected to the pixels (18 uses PWM!).
LED_FREQ_HZ = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
# True to invert the signal (when using NPN transistor level shift)
LED_INVERT = False
LED_CHANNEL = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53


# Define function for changing the colour of all LEDs at once.
def colorWipe(strip, color, wait_ms=50):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)  # Color given as rgb.

    strip.show()
    # time.sleep(wait_ms/1000.0) -- Commented but could be useful
    # for slow transition.


# Main program logic follows:
if __name__ == '__main__':
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--clear', action='store_true',
                        help='clear the display on exit')
    # Useful for testing python code independently from Qt controller.
    args = parser.parse_args()

    # Create NeoPixel object with appropriate configuration.
    strip = Adafruit_NeoPixel(
        LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
    # Intialize the library (must be called once before other functions).
    strip.begin()

    # Get Brightness
    f = open(
        '/home/pi/Traffic Light 2021/build-groupProject-Desktop-Debug/brightness.txt', 'r')
    brightnessString = f.read()
    brightness = int(brightnessString)
    f.close()

    try:
        colorWipe(strip, Color(brightness, 0, 0), 1)  # Red
        print('Red')
        exit()

    except KeyboardInterrupt:
        if args.clear:
            colorWipe(strip, Color(0, 0, 0), 10)
