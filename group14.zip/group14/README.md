# CS3307 Group 14's Project

From gaul server or other environment with required libraries:

- Enter main directory
- Type 'qmake-qt5' (or 'make' if not first time compiling)
- Execute with ./Controller
