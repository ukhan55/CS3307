#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QLabel>
#include <QSlider>
#include <QHBoxLayout>
#include <QTextEdit>
#include <fstream>
#include <iostream>

using std::string;
using std::vector;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    /**
     * @brief instance function used to retrieve the singular instance allowed under the singleton pattern
     */
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    /**
     * @brief Button event handler that changes mode to breathe
     */
    void breatheButton();

    /**
     * @brief Button event handler that changes mode to traffic
     */
    void trafficButton();

    /**
     * @brief Button event handler that changes mode to police
     */
    void policeButton();

    /**
     * @brief Button event handler that changes mode to party
     */
    void partyButton();

    /**
     * @brief Button event handler that changes mode to rainbow
     */
    void rainbowButton();

    /**
     * @brief Button event handler that changes colour to red
     */
    void redB();

    /**
     * @brief Button event handler that changes colour to blue
     */
    void blueB();

    /**
     * @brief Button event handler that changes colour to green
     */
    void greenB();

    /**
     * @brief Button event handler that turns light off
     */
    void offB();

    /**
     * @brief Button event handler that loads/saves to state 1
     */
    void s1B();

    /**
     * @brief Button event handler that loads/saves to state 2
     */
    void s2B();

    /**
     * @brief Button event handler that loads/saves to state 3
     */
    void s3B();

    /**
     * @brief Button event handler that switches to "save" mode
     */
    void saveB();

    /**
     * @brief Button event handler that switches to "load" mode
     */
    void loadB();

    /**
     * @brief Slider event handler that ensures consistent representation of brightness values
     */
    void adjustBrightness();

    /**
     * @brief Helper function that refreshes the current selection string based on the array
     */
    void refreshCurrentSel();

    /**
     * @brief Helper function that simulates the pressing of buttons in current selection
     */
    void useCurrentSel();

    /**
     * @brief Helper function that writes brightness to its text file
     */
    void changeBrightness(int brightness);

    /**
     * @brief Helper function that flips running flag, indicating whether a process is running or not.
     */
    void changeRunFlag(int runFlag);

private:
    /**
     * @brief ofstream used to write to files
     */
    std::ofstream fout;

    /**
     * @brief "Save Load Flag" used to determine whether the controller is currently in a saving or loading state
     */
    int slFlag;

    /**
     * @brief Used to create widgets
     */
    QWidget *widget;

    /**
     * @brief Displays current selections
     */
    QTextEdit *current;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *breatheB;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *trafficB;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *policeB;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *partyB;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *red;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *blue;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *green;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *off;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *s1;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *s2;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *s3;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *save;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *load;

    /**
     * @brief Button for GUI; invokes associated event handler
     */
    QPushButton *rainbowB;

    /**
     * @brief Layout object to hold the colour buttons
     */
    QHBoxLayout *colourButtons;

    /**
     * @brief Layout object to hold the save/load buttons
     */
    QHBoxLayout *saveload;

    /**
     * @brief Layout object to hold the brightness slider
     */
    QHBoxLayout *bright;

    /**
     * @brief Layout object to hold the state buttons
     */
    QHBoxLayout *states;

    /**
     * @brief Layout object to hold the all layouts
     */
    QVBoxLayout *controller;

    /**
     * @brief Layout object to hold the pattern buttons
     */
    QBoxLayout *patternButtons;

    /**
     * @brief Label for coloured buttons
     */
    QLabel *colourLabel;

    /**
     * @brief Label for brightness slider
     */
    QLabel *brightLabel;

    /**
     * @brief Label for entire controller
     */
    QLabel *controllerLabel;

    /**
     * @brief Slider for brightness; invokes associated event handler
     */
    QSlider *brightness;

    /**
     * @brief Array containing currently selected settings.
     */
    std::array<std::string, 3> currentSel; //[0] contains brightness, [1] contains color or mode
};

#endif // MAINWINDOW_H
